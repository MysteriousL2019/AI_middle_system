-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `recentlogin`
--

DROP TABLE IF EXISTS `recentlogin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recentlogin` (
  `idRecentLogin` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `loginTime` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  `userType` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recentlogin`
--

LOCK TABLES `recentlogin` WRITE;
/*!40000 ALTER TABLE `recentlogin` DISABLE KEYS */;
INSERT INTO `recentlogin` VALUES ('1','2023/3/7 01:21:02','lfz','Super Admin'),('1','2023/3/7 01:42:40','lfz','Super Admin'),('1','2023/3/7 01:43:35','User1','Personal User'),('1','2023/3/7 01:43:56','User6','Personal User'),('1','2023/3/7 01:44:00','User5','Personal User'),('1','2023/3/7 12:42:40','lfz','Super Admin'),('1','2023/3/7 12:48:55','lfz','Super Admin'),('1','2023/3/7 12:49:35','lfz','Super Admin'),('1','2023/3/7 12:50:11','lfz','Super Admin'),('1','2023/3/7 12:51:46','lfz','Super Admin'),('1','2023/3/7 13:21:03','User1','Personal User'),('1','2023/3/7 13:37:23','lfz','Super Admin'),('1','2023/3/7 14:00:58','lfz','Super Admin'),('1','2023/3/7 14:10:51','lfz','Super Admin'),('1','2023/3/7 14:11:46','lfz','Super Admin'),('1','2023/3/7 14:12:44','lfz','Super Admin'),('1','2023/3/7 14:13:08','lfz','Super Admin'),('1','2023/3/7 14:13:19','lfz','Super Admin'),('1','2023/3/7 14:14:19','lfz','Super Admin'),('1','2023/3/7 14:15:19','lfz','Super Admin'),('1','2023/3/7 14:15:27','lfz','Super Admin'),('1','2023/3/7 14:26:39','lfz','Super Admin'),('1','2023/3/7 14:29:04','User1','Personal User'),('1','2023/3/7 14:30:06','User2','Personal User'),('1','2023/3/7 15:07:31','User2','Personal User'),('1','2023/3/7 15:13:07','User1','Personal User'),('1','2023/3/7 16:10:06','lfz','Super Admin'),('1','2023/3/7 16:10:15','User1','Personal User'),('1','2023/3/7 16:46:59','lfz','Super Admin'),('1','2023/3/7 16:48:13','lfz','Super Admin'),('1','2023/3/7 16:48:53','lfz','Super Admin'),('1','2023/3/7 16:49:33','lfz','Super Admin'),('1','2023/3/7 16:50:31','lfz','Super Admin'),('1','2023/3/7 16:50:51','User1','Personal User'),('1','2023/3/7 16:51:24','User1','Personal User'),('1','2023/3/7 16:52:03','User1','Personal User'),('1','2023/3/7 16:54:35','User1','Personal User'),('1','2023/3/7 16:55:07','lfz','Super Admin'),('1','2023/3/7 16:55:12','User1','Personal User'),('1','2023/3/7 17:00:09','lfz','Super Admin'),('1','2023/3/7 17:03:00','User1','Personal User'),('1','2023/3/7 17:03:49','lfz','Super Admin'),('1','2023/3/7 17:04:54','lfz','Super Admin'),('1','2023/3/7 17:06:17','User1','Personal User'),('1','2023/3/7 17:10:00','lfz','Super Admin'),('1','2023/3/7 17:11:32','User1','Personal User'),('1','2023/4/2 13:27:51','lfz','Super Admin'),('1','2023/4/2 13:28:27','User1','Personal User'),('1','2023/4/2 14:11:51','User1','Personal User'),('1','2023/4/10 09:53:07','lfz','Super Admin'),('1','2023/4/10 10:01:32','lfz','Super Admin'),('1','2023/4/10 10:04:34','lfz','Super Admin'),('1','2023/4/10 10:22:03','lfz','Super Admin'),('1','2023/4/10 10:41:13','lfz','Super Admin'),('1','2023/4/10 10:43:07','lfz','Super Admin'),('1','2023/4/10 10:44:29','lfz','Super Admin'),('1','2023/4/10 11:34:42','lfz','Super Admin'),('1','2023/4/10 11:36:59','User1','Personal User'),('1','2023/4/10 11:37:08','User1','Personal User'),('1','2023/4/10 11:38:22','lfz','Super Admin'),('1','2023/4/10 12:57:58','User2','Personal User'),('1','2023/4/10 12:58:08','User2','Personal User'),('1','2023/4/10 12:58:45','User2','Personal User'),('1','2023/4/10 13:03:46','lfz','Super Admin'),('1','2023/4/10 13:14:26','lfz','Super Admin'),('1','2023/4/10 13:15:37','lfz','Super Admin'),('1','2023/4/10 13:43:03','lfz','Super Admin'),('1','2023/4/10 13:43:22','User1','Personal User'),('1','2023/4/10 13:58:42','lfz','Super Admin'),('1','2023/4/10 14:09:46','lfz','Super Admin'),('1','2023/4/10 14:09:59','lfz','Super Admin'),('1','2023/4/10 14:19:07','User1','Personal User'),('1','2023/4/10 14:19:28','User2','Personal User'),('1','2023/4/10 14:23:20','User1','Personal User'),('1','2023/4/10 14:36:54','lfz','Super Admin'),('1','2023/4/10 15:40:05','User1','Personal User'),('1','2023/4/10 16:09:45','lfz','Super Admin'),('1','2023/4/10 16:13:10','User1','Personal User'),('1','2023/4/10 16:24:46','lfz','Super Admin'),('1','2023/4/10 16:25:11','User1','Personal User'),('1','2023/4/10 16:37:22','User1','Personal User'),('1','2023/4/10 16:43:41','lfz','Super Admin'),('1','2023/4/10 16:43:47','User1','Personal User'),('1','2023/4/10 20:10:02','lfz','Super Admin'),('1','2023/4/10 20:13:12','User1','Personal User'),('1','2023/4/11 09:31:19','lfz','Super Admin'),('1','2023/4/11 09:31:40','User1','Personal User'),('1','2023/4/11 09:42:58','lfz','Super Admin'),('1','2023/4/11 09:43:07','User1','Personal User'),('1','2023/4/11 09:44:56','User1','Personal User'),('1','2023/4/11 09:46:07','User1','Personal User'),('1','2023/4/11 09:47:22','lfz','Super Admin'),('1','2023/4/11 09:47:28','User1','Personal User'),('1','2023/4/11 10:00:22','User1','Personal User'),('1','2023/4/11 10:07:58','User2','Personal User'),('1','2023/4/11 10:08:11','lfz','Super Admin'),('1','2023/4/11 10:08:34','User2','Personal User'),('1','2023/4/11 10:10:11','User1','Personal User'),('1','2023/4/11 10:11:58','lfz','Super Admin'),('1','2023/4/11 10:16:35','User1','Personal User'),('1','2023/4/11 10:22:46','lfz','Super Admin'),('1','2023/4/11 10:23:26','User1','Personal User'),('1','2023/4/12 14:28:42','lfz','Super Admin'),('1','2023/4/12 14:30:48','User1','Personal User'),('1','2023/4/15 19:54:34','lfz','Super Admin'),('1','2023/4/15 19:55:07','User1','Personal User'),('1','2023/4/15 19:56:10','User1','Personal User'),('1','2023/4/15 20:09:23','User1','Personal User'),('1','2023/4/15 20:09:44','lfz','Super Admin'),('1','2023/4/15 20:11:09','lfz','Super Admin'),('1','2023/4/25 21:47:30','lfz','Super Admin'),('1','2023/4/25 23:31:04','lfz','Super Admin'),('1','2023/4/25 23:41:10','lfz','Super Admin'),('1','2023/4/25 23:42:49','lfz','Super Admin'),('1','2023/4/25 23:43:56','lfz','Super Admin'),('1','2023/4/25 23:45:15','lfz','Super Admin'),('1','2023/4/25 23:46:11','User1','Personal User'),('1','2023/4/25 23:46:27','lfz','Super Admin'),('1','2023/4/26 00:00:20','User1','Personal User'),('1','2023/4/26 00:00:33','User1','Personal User'),('1','2023/4/26 00:01:17','User2','Personal User'),('1','2023/4/26 00:02:13','lfz','Super Admin'),('1','2023/5/4 00:52:10','lfz','Super Admin'),('1','2023/5/4 00:52:44','lfz','Super Admin'),('1','2023/5/4 00:52:52','User1','Personal User'),('1','2023/5/4 00:53:16','lfz','Super Admin'),('1','2023/5/4 00:57:28','lfz','Super Admin'),('1','2023/5/4 00:57:44','lfz','Super Admin'),('1','2023/5/4 00:59:49','lfz','Super Admin'),('1','2023/5/4 00:59:57','User1','Personal User'),('1','2023/5/4 01:00:06','User2','Personal User'),('1','2023/5/4 01:00:13','lfz','Super Admin'),('1','2023/5/4 01:00:33','User1','Personal User'),('1','2023/5/4 01:00:38','lfz','Super Admin'),('1','2023/5/4 01:01:42','User1','Personal User'),('1','2023/5/4 09:27:33','lfz','Super Admin'),('1','2023/5/4 09:31:13','User1','Personal User'),('1','2023/5/4 10:18:20','User1','Personal User'),('1','2023/5/4 10:24:13','User1','Personal User'),('1','2023/5/4 10:33:11','lfz','Super Admin'),('1','2023/5/4 10:33:23','User1','Personal User'),('1','2023/5/4 10:37:33','User1','Personal User'),('1','2023/5/4 13:34:06','User1','Personal User'),('1','2023/5/4 14:03:21','User1','Personal User'),('1','2023/5/7 15:52:29','lfz','Super Admin'),('1','2023/5/7 15:56:54','User1','Personal User'),('1','2023/5/7 16:06:28','lfz','Super Admin'),('1','2023/5/7 16:08:58','User1','Personal User'),('1','2023/5/8 11:36:49','lfz','Super Admin'),('1','2023/5/8 11:44:45','lfz','Super Admin'),('1','2023/5/8 11:48:17','lfz','Super Admin'),('1','2023/5/8 11:48:23','lfz','Super Admin'),('1','2023/5/8 11:49:01','lfz','Super Admin'),('1','2023/5/8 12:15:46','lfz','Super Admin'),('1','2023/5/8 12:27:24','lfz','Super Admin'),('1','2023/5/8 12:32:03','lfz','Super Admin'),('1','2023/5/8 12:32:19','lfz','Super Admin'),('1','2023/5/8 12:34:37','lfz','Super Admin'),('1','2023/5/8 12:47:23','lfz','Super Admin'),('1','2023/5/8 12:48:30','lfz','Super Admin'),('1','2023/5/9 09:51:47','lfz','Super Admin'),('1','2023/5/9 09:53:16','User1','Personal User'),('1','2023/5/9 10:01:32','lfz','Super Admin'),('1','2023/5/9 10:03:56','User1','Personal User'),('1','2023/5/9 13:35:32','lfz','Super Admin'),('1','2023/5/9 13:35:59','lfz','Super Admin'),('1','2023/5/9 13:38:24','User1','Personal User'),('1','2023/5/9 15:13:09','lfz','Super Admin'),('1','2023/5/9 15:15:45','User1','Personal User');
/*!40000 ALTER TABLE `recentlogin` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-08 16:53:51
