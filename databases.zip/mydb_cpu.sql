-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cpu`
--

DROP TABLE IF EXISTS `cpu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpu` (
  `idCPU` int NOT NULL,
  `typeCPU` varchar(45) DEFAULT '赫兹，型号',
  `RAMCPU` varchar(45) DEFAULT NULL,
  `User_idUser` int DEFAULT NULL,
  `bandwidth` varchar(45) DEFAULT NULL,
  `isAvailable` int DEFAULT NULL,
  PRIMARY KEY (`idCPU`),
  KEY `fk_CPU_User_idx` (`User_idUser`),
  CONSTRAINT `fk_CPU_User` FOREIGN KEY (`User_idUser`) REFERENCES `user` (`idUser`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpu`
--

LOCK TABLES `cpu` WRITE;
/*!40000 ALTER TABLE `cpu` DISABLE KEYS */;
INSERT INTO `cpu` VALUES (30001,'1 core','1G',NULL,'1M',1),(30002,'1 core','1G',20001,'1M',1),(30003,'1 core','1G',20002,'1M',1),(30004,'2 core','4G',20001,'3M',1),(30005,'2 core','4G',20002,'3M',1),(30006,'2 core','4G',20001,'3M',1),(30007,'2 core','8G',20001,'5M',1),(30008,'2 core','8G',NULL,'5M',1),(30009,'2 core','8G',NULL,'5M',1),(30010,'2 core','8G',20001,'5M',1),(30011,'2 core','8G',NULL,'5M',1),(30012,'4 core','8G',NULL,'8M',1),(30013,'4 core','8G',NULL,'8M',1),(30014,'4 core','8G',NULL,'8M',1),(30015,'8 core','16G',NULL,'10M',1),(30016,'8 core','16G',NULL,'10M',1),(30017,'8 core','16G',NULL,'10M',1),(30018,'8 core','16G',NULL,'10M',1),(30019,'8 core','16G',NULL,'10M',1),(30020,'8 core','16G',NULL,'10M',1),(30021,'1 core','2G',NULL,'1M',1),(30022,'16 core','4G',NULL,'1M',1),(30023,'1 core','2G',NULL,'1M',1);
/*!40000 ALTER TABLE `cpu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-08 16:53:51
