-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `logrecords`
--

DROP TABLE IF EXISTS `logrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `logrecords` (
  `username` varchar(255) DEFAULT NULL,
  `time` datetime NOT NULL,
  `usertype` varchar(255) DEFAULT NULL,
  `operationType` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logrecords`
--

LOCK TABLES `logrecords` WRITE;
/*!40000 ALTER TABLE `logrecords` DISABLE KEYS */;
INSERT INTO `logrecords` VALUES ('lfz','2023-01-04 16:59:57','Super Admin','addUser','success'),('lfz','2023-01-04 22:41:42','Super Admin','addUer','success'),('lfz','2023-01-04 22:47:51','Super Admin','addUer','success'),('lfz','2023-03-05 22:10:11','Super Admin','changeAnnouncement','success'),('lfz','2023-03-06 21:27:14','Super Admin','changeAnnouncement','success'),('lfz','2023-03-06 23:28:09','Super Admin','addUer','success'),('lfz','2023-03-06 23:28:51','Super Admin','editUser','success'),('lfz','2023-03-06 23:31:44','Super Admin','editUser','success'),('lfz','2023-03-06 23:32:29','Super Admin','editUser','success'),('lfz','2023-03-06 23:35:03','Super Admin','editUser',''),('lfz','2023-03-06 23:40:48','Super Admin','editUser',''),('lfz','2023-03-07 12:48:59','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:49:00','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:49:21','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:49:30','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:49:31','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:50:14','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 12:51:43','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 17:10:16','Super Admin','changeAnnouncement','success'),('lfz','2023-03-07 17:11:06','Super Admin','changeAnnouncement','success'),('lfz','2023-04-02 13:28:00','Super Admin','changeAnnouncement','success'),('lfz','2023-04-10 13:16:14','Super Admin','addGPU','success'),('lfz','2023-04-10 14:38:52','Super Admin','changeAnnouncement','success'),('lfz','2023-04-10 14:38:58','Super Admin','changeAnnouncement','success'),('User1','2023-04-10 16:24:10','Personal User','returnCPU','success'),('User1','2023-04-10 16:24:28','Personal User','use GPU','success'),('User1','2023-04-10 16:24:40','Personal User','returnCPU','success'),('User1','2023-04-11 10:02:25','Personal User','updateModel','success'),('User1','2023-04-11 10:06:59','Personal User','submitDataSet','fail'),('User1','2023-04-11 10:07:38','Personal User','submitDataSet','success'),('User1','2023-04-11 10:07:48','Personal User','deleteDataSet','success'),('User1','2023-04-11 10:24:04','Personal User','returnHD','success'),('lfz','2023-04-12 14:28:55','Super Admin','changeAnnouncement','success'),('lfz','2023-04-12 14:29:43','Super Admin','addUer','success'),('lfz','2023-04-12 14:29:49','Super Admin','deleteUser','success'),('User1','2023-04-12 14:31:08','Personal User','submitDataSet','fail'),('User1','2023-04-15 19:56:21','Personal User','use CPU','success'),('User1','2023-04-15 20:04:44','Personal User','useHD','success'),('lfz','2023-04-25 23:46:35','Super Admin','changeAnnouncement','success'),('lfz','2023-05-04 01:00:25','Super Admin','changeAnnouncement','success'),('lfz','2023-05-04 09:30:22','Super Admin','changeAnnouncement','success'),('lfz','2023-05-07 15:52:54','Super Admin','changeAnnouncement','success'),('lfz','2023-05-07 15:53:12','Super Admin','changeAnnouncement','success'),('lfz','2023-05-07 15:55:12','Super Admin','addUer','success'),('lfz','2023-05-07 15:55:23','Super Admin','editUser','success'),('lfz','2023-05-07 15:55:26','Super Admin','deleteUser','success'),('lfz','2023-05-08 12:28:16','Super Admin','changeAnnouncement','success'),('lfz','2023-05-09 09:52:18','Super Admin','changeAnnouncement','success'),('lfz','2023-05-09 10:01:59','Super Admin','changeAnnouncement','success'),('lfz','2023-05-09 13:36:28','Super Admin','changeAnnouncement','success'),('User1','2023-05-09 13:39:11','Personal User','useHD','success'),('User1','2023-05-09 13:39:26','Personal User','returnHD','success'),('User1','2023-05-09 13:40:33','Personal User','submitDataSet','success'),('User1','2023-05-09 13:40:36','Personal User','deleteDataSet','success'),('User1','2023-05-09 13:42:08','Personal User','updateModel','success'),('lfz','2023-05-09 15:13:45','Super Admin','changeAnnouncement','success'),('User1','2023-05-09 15:16:49','Personal User','use CPU','success'),('User1','2023-05-09 15:17:12','Personal User','returnCPU','success');
/*!40000 ALTER TABLE `logrecords` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-09-08 16:53:50
